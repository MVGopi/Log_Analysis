
CREATE VIEW l_a as SELECT replace(path,'/article/','') as slug, count(*) as views
FROM log
WHERE path<>'/' AND status ='200 OK' GROUP BY path;


CREATE VIEW l_n as SELECT authors.name as name, articles.slug as slug
FROM authors INNER JOIN articles
ON articles.author=authors.id
ORDER BY authors.id;

CREATE VIEW l_t as SELECT Date(time), count(Date(time)) 
FROM log
GROUP BY Date(time);

CREATE VIEW l_f as SELECT Date(time), count(Date(time))
FROM log
WHERE status='404 NOT FOUND' GROUP BY Date(time) ORDER BY Date(time);